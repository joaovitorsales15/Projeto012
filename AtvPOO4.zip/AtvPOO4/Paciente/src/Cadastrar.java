import javax.swing.*;

public class Cadastrar {

        public static void main(String[] args) {
            Paciente cp;

            String nome,rg,endereco,telefone,profissao;
            int anoNascimento;

            nome = JOptionPane.showInputDialog("Nome do paciente: ");
            rg = JOptionPane.showInputDialog("RG do paciente: ");
            endereco = JOptionPane.showInputDialog("Endereço do paciente: ");
            telefone = JOptionPane.showInputDialog("Telefone do paciente: ");
            profissao = JOptionPane.showInputDialog("Profissão do paciente: ");
            anoNascimento = Integer.parseInt(JOptionPane.showInputDialog("Nascimento do paciente: "));


            cp = new Paciente(nome,rg,endereco,telefone,anoNascimento,profissao);

            cp.imprimeDados();
            anoNascimento=cp.calcularIdade();
            JOptionPane.showMessageDialog(null, "A idade do paciente é: "+anoNascimento);

        }
}
