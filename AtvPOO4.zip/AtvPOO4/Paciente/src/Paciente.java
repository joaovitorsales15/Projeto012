import javax.swing.*;

public class Paciente {
    String nome;
    String rg;
    String endereco;
    String telefone;
    int anoNascimento;
    String profissao;



    public Paciente(){}

    public Paciente(String nome, String rg, String endereco,String telefone,int anoNascimento,String profissao){
        this.nome = nome;
        this.rg = rg;
        this.endereco = endereco;
        this.telefone = telefone;
        this.anoNascimento = anoNascimento;
        this.profissao = profissao;
    }
    void cadastrarCurso(){

    }
    void imprimeDados() {
        JOptionPane.showConfirmDialog(null, "Dados do cliente: " +
                "\nNome: " + nome +
                "\nRG: " + rg +
                "\nEndereço: " + endereco +
                "\nTelefone: " + telefone +
                "\nNascimento: " + anoNascimento +
                "\nProfissão: " + profissao
                );
    }
    int calcularIdade() {
        int anoatual,idade;
        anoatual = 2022;
        idade = anoatual - anoNascimento;
        return idade;
    }
}
