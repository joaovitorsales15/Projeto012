import javax.swing.*;

public class TestePoupanca {

    public static void main(String[] args) {
        ContaPoupanca cp;

        float mensalidade ;
        String nome,turma;
        int quantidadedealunos;

        nome = JOptionPane.showInputDialog("Digite o nome do curso: ");
        quantidadedealunos = Integer.parseInt(JOptionPane.showInputDialog("Quantidade de alunos: "));
        turma = JOptionPane.showInputDialog("Quantas turmas existem?: ");
        mensalidade = Float.parseFloat(JOptionPane.showInputDialog("Digite o valor da mensalidade: "));

        cp = new ContaPoupanca(nome, quantidadedealunos,turma,mensalidade);

        cp.imprimeDados();
        mensalidade=cp.calcularTotalMensalidade();
        JOptionPane.showMessageDialog(null, "O total da mensalidade é: "+mensalidade);
    }
}
