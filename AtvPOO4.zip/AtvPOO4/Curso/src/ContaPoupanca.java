import javax.swing.*;

public class ContaPoupanca {
    String nome;
    int quantidadedealunos;
    String turma;
    float mensalidade;

    public ContaPoupanca(){}

    public ContaPoupanca(String nome, int quantidadedealunos,String turma, float mensalidade){
        this.nome = nome;
        this.quantidadedealunos = quantidadedealunos;
        this.turma = turma;
        this.mensalidade = mensalidade;
    }
    void cadastrarCurso(){

    }
    void imprimeDados() {
        JOptionPane.showConfirmDialog(null, "Dados da conta corrente: " +
                "\nNome: " + nome +
                "\nQuantidade de aluno: " + quantidadedealunos +
                "\nTurma: " + turma +
                "\nMensalidade: " + mensalidade);
    }
    float calcularTotalMensalidade() {
        float total;
        total = quantidadedealunos * mensalidade;
        return total;
    }
}



