public class Curso {
    String nome;
    int quantidadealunos;
    String turma;
    float mensalidade;

    public Curso(){}
    public Curso(String nome, int quantidadealunos, String turma, float mensalidade){
        this.nome = nome;
        this.quantidadealunos = quantidadealunos;
        this.turma = turma;
        this.mensalidade = mensalidade;
    }
    void cadastraCurso( {
        public static void main (String[]args){
            CadastrarCurso cadastrarCurso = new CadastrarCurso();
        }
    }
    void imprimeDados(){
        JOptionPane.showMessageDialog(null, "Nome do curso: " + nome
                "\nQuantidade de aluno: " + quantidadealunos +
                "\nTurma: " + turma +
                "\nMensalidade: " + mensalidade)
    }

    float calculaTotalMensalidade(float m){
        return mensalidade;
    };
}
